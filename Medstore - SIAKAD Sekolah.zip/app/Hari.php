<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hari extends Model
{
    // Model Hari
    protected $table = 'hari';
    protected $primaryKey = 'id_hari';
    public $timestamps = true;
}
